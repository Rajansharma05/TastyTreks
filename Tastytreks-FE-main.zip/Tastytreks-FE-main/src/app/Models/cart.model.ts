import { Products } from "./products";

export class Cart{
    id!:number;
    quantity!:number;
    price!:number;
    product!:Products;
}
