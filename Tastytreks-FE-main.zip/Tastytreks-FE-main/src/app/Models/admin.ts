export class Admin {
  userName: string | undefined;
  emailId: string | undefined;
  phoneNo: string | undefined;
  password: string | undefined;
}

export class LoginAdminData {
  emailId: string | undefined;
  password: string | undefined;
}
