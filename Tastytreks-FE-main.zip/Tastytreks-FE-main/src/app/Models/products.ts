
   export class Products{
    id : number =0;
	name : string='';
	cuisines :string='';
	description:string='';
	price:number =0;
	offers:number =0;
	avail:string='';
	imagepath:string='';
   }