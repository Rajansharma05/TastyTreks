package com.TastyTreks.Service;

public class Service {

}
