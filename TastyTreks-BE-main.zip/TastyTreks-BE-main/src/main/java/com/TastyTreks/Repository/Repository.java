package com.TastyTreks.Repository;

public class Repository {

}
